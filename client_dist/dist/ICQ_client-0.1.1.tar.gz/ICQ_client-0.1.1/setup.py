from setuptools import setup, find_packages

setup(name='ICQ_client',
      version='0.1.1',
      description='ICQ_client',
      author='Evseev Yurii',
      author_email='mousedrw@ya.ru',
      packages=find_packages(),
      install_requires=['PyQt5', 'sqlalchemy', 'pycryptodome', 'pycryptodomex']
      )
